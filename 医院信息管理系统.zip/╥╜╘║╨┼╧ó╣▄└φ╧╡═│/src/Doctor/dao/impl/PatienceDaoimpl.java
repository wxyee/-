package Doctor.dao.impl;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import Doctor.dao.IPatienceDao;
import Doctor.poto.Patience;


public  class PatienceDaoimpl implements IPatienceDao{

	@Override
	public int insert(Patience c) {
		// 从文件中拿到数据集合
		List<Patience> Patients = getDataSource();
		
		//将对象添加到数据集合中
		// 获取最大id，加1后，作为当前联系人的id
		int maxid = 0;
		for (Patience con : Patients) {
			if (con.getId() > maxid) {
				maxid = con.getId();
			}
		}
		c.setId(maxid + 1);
		Patients.add(c);
		
		//将数据集合写到文件中
		return saveDataSource(Patients);
		
		
	}

	@Override 
	public int delete(int id) {
		// （从文件中得到数据集合->将指定数据删除->写回去）
				List<Patience> patient = getDataSource();
				
				// 如果需要在一次循环中删除/添加多个元素==》列表元素的结构改变，要小心！
				for (Patience c : patient) {
					if (c.getId() == id) {
						patient.remove(c);
						saveDataSource(patient);
						return 1;
					}
				}
				
				return 0;
	}

	@Override
	public int update(Patience c) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<Patience> queryAll(String username) {
		List<Patience> result = new ArrayList<>();

		// 1、从文件中拿到数据集合
		List<Patience> Patients = getDataSource();

		 //2、遍历集合进行查询
		for (Patience c : Patients) {
			if (c.getUsername().equals(username)) {
				result.add(c);
			}
		}
		 //3、返回结果集合
		return result;
	}

	@Override
	public List<Patience> querypname(String username,String pname) {
		List<Patience> result = new ArrayList<>();

		// 1、从文件中拿到数据集合
		List<Patience> Patients = getDataSource();

		// 2、遍历集合进行查询
		for (Patience c : Patients) {
			// equals 需要内容相等，所以是精确匹配
			//if (c.getUsername().equals(username) && c.getName().equals(name)) {
			
			// contains 判断是否包含一部分，所以是模糊匹配
			if (c.getUsername().equals(username) && c.getPname().contains(pname)) {
				result.add(c);
			}
		}

		// 3、返回结果集合
		return result;
	}

	public Patience querypcall(String username,String pcall) {
		// 1、从文件中拿到数据集合
				List<Patience> Patients = getDataSource();

				// 2、遍历集合进行查询
				for (Patience c : Patients) {
					if (c.getUsername().equals(username) && c.getPcall().equals(pcall)) {
						return c;
					}
				}

				return null;
	}
	public List<Patience> querypill(String username,String pill) {
		List<Patience> result = new ArrayList<>();

		// 1、从文件中拿到数据集合
		List<Patience> Patients = getDataSource();

		// 2、遍历集合进行查询
		for (Patience c : Patients) {
			// equals 需要内容相等，所以是精确匹配
			if (c.getUsername().equals(username) && c.getPill().equals(pill)) {			
				result.add(c);
			}
		}

		// 3、返回结果集合
		return result;
	}
	
	
	private List<Patience> getDataSource() {
		// 实际的数据操作
		List<Patience> Patients = null;

		try {
			File dataFile = new File("Patients.data");
			FileInputStream fis = new FileInputStream(dataFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			Patients = (List<Patience>) ois.readObject();
			ois.close();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		if (Patients == null) {
			// 可能是文件不存在，可能是读写过程中出错
			Patients = new ArrayList<>();
		}

		return Patients;
	}

	private int saveDataSource(List<Patience> Patients) {
		try {
			File dataFile = new File("Patients.data");
			FileOutputStream fos = new FileOutputStream(dataFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(Patients);
			oos.close();
		} catch (IOException e) {
			e.printStackTrace();
			return 0;
		}
		return 1;
	}

	

	
}
