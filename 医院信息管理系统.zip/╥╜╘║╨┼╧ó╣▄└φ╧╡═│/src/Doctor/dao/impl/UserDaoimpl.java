package Doctor.dao.impl;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import Doctor.dao.IUserDao;
import Doctor.poto.User;



public class UserDaoimpl implements IUserDao {

	@Override
	public User queryByUsernamePassword(String username, String password) {
		// 1、从文件中拿到数据集合
		List<User> users = getDataSource();

		// 2、从集合中查找username和password是否存在
		for (User u : users) {
			if (u.getUsername().equals(username) && u.getPassword().equals(password)) {
				return u;
			}
		}

		return null;
	}

	@Override
	public int insert(User user) {
		// 1、从文件中拿到数据集合
		List<User> users = getDataSource();

		// 2、将user对象添加到数据集合
		users.add(user);

		// 3、将数据集合写到文件
		return saveDataSource(users);
	}

	@Override
	public User queryByUsername(String username) {
		// 1、从文件中拿到数据集合
		List<User> users = getDataSource();

		// 2、从集合中查找username是否存在
		for (User u : users) {
			if (u.getUsername().equals(username)) {
				return u;
			}
		}

		return null;
	}

	private List<User> getDataSource() {
		// 实际的数据操作
		List<User> users = null;

		try {
			File dataFile = new File("users.data");
			FileInputStream fis = new FileInputStream(dataFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			users = (List<User>) ois.readObject();
			ois.close();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		if (users == null) {
			// 可能是文件不存在，可能是读写过程中出错
			users = new ArrayList<>();
		}

		return users;
	}

	private int saveDataSource(List<User> users) {
		try {
			File dataFile = new File("users.data");
			FileOutputStream fos = new FileOutputStream(dataFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(users);
			oos.close();
		} catch (IOException e) {
			e.printStackTrace();
			return 3;
		}
		return 0;
	}

}
