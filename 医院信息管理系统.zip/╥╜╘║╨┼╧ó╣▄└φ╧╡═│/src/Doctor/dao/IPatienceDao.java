package Doctor.dao;

import java.util.List;

import Doctor.poto.Patience;

public interface IPatienceDao {
	//增
	
		int insert(Patience c);
		
		//删
		
		int delete(int id);
		
		//改    根据id
		
		int update(Patience c);
		
		//查
		List<Patience> queryAll(String username);
		
		//查名字
		List<Patience> querypname(String username,String pname);
		
		//查联系方式
		Patience querypcall(String username,String pcall);
		
		//查病症
		List<Patience> querypill(String username,String pill);

}
