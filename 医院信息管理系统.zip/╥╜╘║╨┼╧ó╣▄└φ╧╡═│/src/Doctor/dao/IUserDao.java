package Doctor.dao;

import Doctor.poto.User;

public interface IUserDao {
	// 对用户进行查询操作
	User queryByUsernamePassword(String username, String password);
	User queryByUsername(String username);
	
	// 对用户进行添加操作
	int insert(User user);
}

