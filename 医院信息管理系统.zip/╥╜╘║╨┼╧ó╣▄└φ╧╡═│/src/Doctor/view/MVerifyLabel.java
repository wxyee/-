package Doctor.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class MVerifyLabel extends JLabel {
	// 验证码字符集
	private static final char[] chars = ("0123456789abcdefghijklmnopqrstuvwxyz" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
			.toCharArray();
	// 字符数量
	private static final int SIZE = 4;
	// 干扰线数量
	private static final int LINES = 10;
	
	// 字体大小
	private static final int FONT_SIZE = 30;// 30
	
	// 验证码字符串
	private String code = "";
	// 验证码图片
	private BufferedImage image = null;
	
	public String getCode() {
		return code;
	}
	
	public MVerifyLabel() {
		super();
		this.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				super.componentResized(e);
				createImage();
			}
		});
		
		this.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				createImage();
			}
		});
	}

	/**
	 * 生成随机验证码及图片
	 */
	private void createImage() {
		int width = this.getWidth();
		int height = this.getHeight();
		
		
		StringBuffer sb = new StringBuffer();
		// 1.创建空白图片
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		// 2.获取图片画笔
		Graphics graphic = image.getGraphics();
		// 3.设置画笔颜色
		graphic.setColor(Color.LIGHT_GRAY);
		// 4.绘制矩形背景
		graphic.fillRect(0, 0, width, height);
		// 5.画随机字符
		Random ran = new Random();
		for (int i = 0; i < SIZE; i++) {
			// 取随机字符索引
			int n = ran.nextInt(chars.length);
			// 设置随机颜色
			graphic.setColor(getRandomColor());
			// 设置字体大小
			graphic.setFont(new Font(null, Font.BOLD + Font.ITALIC, height));
			// 画字符
			graphic.drawString(chars[n] + "", i * width / SIZE, height - 4);
			// 记录字符
			sb.append(chars[n]);
		}
		// 6.画干扰线
		for (int i = 0; i < LINES; i++) {
			// 设置随机颜色
			graphic.setColor(getRandomColor());
			// 随机画线
			graphic.drawLine(ran.nextInt(width), ran.nextInt(height), ran.nextInt(width), ran.nextInt(height));
		}
		// 7.返回验证码和图片
		code = sb.toString();
		this.setIcon(new ImageIcon(image));
	}

	/**
	 * 随机取色
	 */
	private Color getRandomColor() {
		Random ran = new Random();
		Color color = new Color(ran.nextInt(256), ran.nextInt(256), ran.nextInt(256));
		return color;
	}
	
}
