package Doctor.view;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * 带图片背景，且按窗口大小自动缩放的JPanel
 */
public class MImagePanel extends JPanel {

	private static final long serialVersionUID = 3602544785116642939L;
	private ImageIcon imageIcon = null;

	public MImagePanel(URL imgUrl) {
		super();
		imageIcon = new ImageIcon(imgUrl);
	}
	
	public MImagePanel(String imgFile) {
		super();
		imageIcon = new ImageIcon(imgFile);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		if (imageIcon != null) {
			int width = this.getWidth();
			int height = this.getHeight();
			int iconWidth = imageIcon.getIconWidth();
			int iconHeight = imageIcon.getIconHeight();

			g.drawImage(imageIcon.getImage(), 0, 0, width, height, 0, 0, iconWidth, iconHeight, null);
		}
	}
	
}
