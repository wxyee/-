package Doctor.view;




import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.CardLayout;
import java.awt.EventQueue;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


import Doctor.poto.Patience;
import Doctor.poto.User;
import Doctor.poto.doctor;
//import Doctor.poto.doctor;
//import Doctor.service.IDoctor;
import Doctor.service.IPatience;
import Doctor.service.impl.Patienceimpl;
//import Doctor.service.impl.dDoctorimpl;

import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.ListSelectionModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class Message extends JFrame {

	private JPanel contentPane;
	private JTable tablepatient;
	private User user;
	private JTextField qwname;
	private JTextField qwage;
	private JTextField qwzhicheng;
	private JTextField qwid;
	private JTextField qwkeshi;
	private JTable table;
	private JTextField tid;
	private JTextField tname;
	private JTextField tage;
	private JTextField tfcollege;
	private JTextField tfroom;
	private JTextField tcall;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Message frame = new Message();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public Message() {
		setTitle("医生您好");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 779, 529);
		setLocationRelativeTo(null); // 设置屏幕居中
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JPanel seepanel = new JPanel();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(seepanel, GroupLayout.DEFAULT_SIZE, 608, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(seepanel, GroupLayout.PREFERRED_SIZE, 396, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		seepanel.setLayout(new CardLayout(0, 0));
		
		JPanel personal = new JPanel();
		seepanel.add(personal, "name_673245379164900");
		
		JLabel label_1 = new JLabel("个人资料");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("微软雅黑", Font.BOLD, 20));
		
		JLabel label_2 = new JLabel("病人查看");
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((CardLayout)seepanel.getLayout()).show(seepanel, "name_673258034143900");
			}
		});
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("微软雅黑", Font.BOLD, 20));
		
		JLabel lblNewLabel = new JLabel("值班情况");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((CardLayout)seepanel.getLayout()).show(seepanel, "name_673360697024500");
			}
		});
		lblNewLabel.setFont(new Font("微软雅黑", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JPanel Person = new JPanel();
		GroupLayout gl_personal = new GroupLayout(personal);
		gl_personal.setHorizontalGroup(
			gl_personal.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_personal.createSequentialGroup()
					.addGroup(gl_personal.createParallelGroup(Alignment.LEADING)
						.addComponent(label_1)
						.addComponent(label_2)
						.addComponent(lblNewLabel))
					.addGap(18)
					.addComponent(Person, GroupLayout.DEFAULT_SIZE, 535, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_personal.setVerticalGroup(
			gl_personal.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_personal.createSequentialGroup()
					.addGap(130)
					.addComponent(label_1)
					.addGap(18)
					.addComponent(label_2)
					.addGap(18)
					.addComponent(lblNewLabel)
					.addContainerGap(146, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_personal.createSequentialGroup()
					.addContainerGap()
					.addComponent(Person, GroupLayout.DEFAULT_SIZE, 396, Short.MAX_VALUE))
		);
		
		JLabel lblNewLabel_2 = new JLabel("医师姓名：");
		lblNewLabel_2.setFont(new Font("宋体", Font.BOLD, 15));
		
		JLabel label_14 = new JLabel("年    龄：");
		label_14.setFont(new Font("宋体", Font.BOLD, 15));
		
		JLabel lblNewLabel_3 = new JLabel("性    别：");
		lblNewLabel_3.setFont(new Font("宋体", Font.BOLD, 15));
		
		JLabel lblNewLabel_4 = new JLabel("职    称：");
		lblNewLabel_4.setFont(new Font("宋体", Font.BOLD, 15));
		
		JLabel lblNewLabel_5 = new JLabel("身份证号：");
		lblNewLabel_5.setFont(new Font("宋体", Font.BOLD, 15));
		
		JLabel lblNewLabel_6 = new JLabel("科    室：");
		lblNewLabel_6.setFont(new Font("宋体", Font.BOLD, 15));
		
		qwname = new JTextField();
		qwname.setColumns(10);
		
		qwage = new JTextField();
		qwage.setColumns(10);
		
		JRadioButton radioma = new JRadioButton("男");
		buttonGroup.add(radioma);
		
		JRadioButton radiofema = new JRadioButton("女");
		buttonGroup.add(radiofema);
		
		qwzhicheng = new JTextField();
		qwzhicheng.setColumns(10);
		
		qwid = new JTextField();
		qwid.setColumns(10);
		
		qwkeshi = new JTextField();
		qwkeshi.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("修改");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				qwname.enable(true);
				qwid.enable(true);
				qwkeshi.enable(true);
				qwzhicheng.enable(true);
				radioma.enable(true);
				radiofema.enable(true);
				qwage.enable(true);
			}
		});
		
		JButton btnNewButton_4 = new JButton("保存");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				qwname.enable(false);
				qwid.enable(false);
				qwkeshi.enable(false);
				qwzhicheng.enable(false);
				radioma.enable(false);
				radiofema.enable(false);
				qwage.enable(false);
				
			}
		});
		GroupLayout gl_Person = new GroupLayout(Person);
		gl_Person.setHorizontalGroup(
			gl_Person.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Person.createSequentialGroup()
					.addGroup(gl_Person.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2)
						.addComponent(label_14)
						.addComponent(lblNewLabel_4)
						.addComponent(lblNewLabel_5)
						.addComponent(lblNewLabel_6))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_Person.createParallelGroup(Alignment.LEADING)
						.addComponent(qwkeshi, 130, 130, 130)
						.addComponent(qwid, 130, 130, 130)
						.addComponent(qwzhicheng, 130, 130, 130)
						.addComponent(qwage, 130, 130, 130)
						.addComponent(qwname, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE))
					.addGap(318))
				.addGroup(gl_Person.createSequentialGroup()
					.addComponent(btnNewButton_3)
					.addPreferredGap(ComponentPlacement.RELATED, 102, Short.MAX_VALUE)
					.addComponent(btnNewButton_4)
					.addGap(353))
				.addGroup(gl_Person.createSequentialGroup()
					.addComponent(lblNewLabel_3)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(radioma)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(radiofema)
					.addGap(395))
		);
		gl_Person.setVerticalGroup(
			gl_Person.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Person.createSequentialGroup()
					.addGap(68)
					.addGroup(gl_Person.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(qwname, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_Person.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_14)
						.addComponent(qwage, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_Person.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(radioma)
						.addComponent(radiofema))
					.addGap(18)
					.addGroup(gl_Person.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_4)
						.addComponent(qwzhicheng, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_Person.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_5)
						.addComponent(qwid, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_Person.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_6)
						.addComponent(qwkeshi, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_Person.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_3)
						.addComponent(btnNewButton_4))
					.addContainerGap(33, Short.MAX_VALUE))
		);
		Person.setLayout(gl_Person);
		personal.setLayout(gl_personal);
		
		JPanel patient = new JPanel();
		seepanel.add(patient, "name_673258034143900");
		
		JLabel label_7 = new JLabel("个人资料");
		label_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((CardLayout)seepanel.getLayout()).show(seepanel, "name_673245379164900");
			}
		});
 		label_7.setFont(new Font("微软雅黑", Font.BOLD, 20));
		
		JLabel label_8 = new JLabel("病人查看");
		label_8.setFont(new Font("微软雅黑", Font.BOLD, 20));
		
		JLabel label_9 = new JLabel("值班情况");
		label_9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((CardLayout)seepanel.getLayout()).show(seepanel, "name_673360697024500");
			}
		});
		label_9.setFont(new Font("微软雅黑", Font.BOLD, 20));
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton button = new JButton("添加病人");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addpatient dialog = new addpatient();
				dialog.setUsername(user.getUsername());
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				
				dialog.setLocationRelativeTo(Message.this); // 添加设置屏幕居中
				dialog.setModal(true);  //设置为模态对话框
				dialog.setVisible(true);
				
				IPatience patientsService = new Patienceimpl();
				List<Patience> patients = patientsService.queryAll(user.getUsername());
				showPatience(patients);
			}
			
		});
		
		JButton button_1 = new JButton("删除病人");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// 1、获取要删除的目标 --> id
				int row = tablepatient.getSelectedRow();
				if (row == -1) {
					JOptionPane.showMessageDialog(Message.this, "必须先选中要删除的联系人！！");
					return;
				}
				int id = (int) tablepatient.getValueAt(row, 0);

				// 2、到底层去删除
				int rlt = JOptionPane.showConfirmDialog(Message.this, "确定要删除该联系人吗？", "删除联系人",
						JOptionPane.YES_NO_OPTION);
				if (rlt == JOptionPane.YES_OPTION) {
					IPatience contactService = new Patienceimpl();
					rlt = contactService.delete(id);
					if (rlt == 1) {
						JOptionPane.showMessageDialog(Message.this, "删除完成！！");
						// 删除完成后，重新刷新数据
						List<Patience> contacts = contactService.queryAll(user.getUsername());
						showPatience(contacts);
					} else {
						JOptionPane.showMessageDialog(Message.this, "删除失败！！");
					}
				}
				
			}
		});
		GroupLayout gl_patient = new GroupLayout(patient);
		gl_patient.setHorizontalGroup(
			gl_patient.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_patient.createSequentialGroup()
					.addGroup(gl_patient.createParallelGroup(Alignment.LEADING)
						.addComponent(label_7)
						.addComponent(label_8)
						.addComponent(label_9))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_patient.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_patient.createSequentialGroup()
							.addComponent(button)
							.addPreferredGap(ComponentPlacement.RELATED, 335, Short.MAX_VALUE)
							.addComponent(button_1))
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 521, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_patient.setVerticalGroup(
			gl_patient.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_patient.createSequentialGroup()
					.addGroup(gl_patient.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_patient.createSequentialGroup()
							.addGap(111)
							.addComponent(label_7)
							.addGap(18)
							.addComponent(label_8)
							.addGap(18)
							.addComponent(label_9))
						.addGroup(gl_patient.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 309, GroupLayout.PREFERRED_SIZE)))
					.addGroup(gl_patient.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_patient.createSequentialGroup()
							.addGap(13)
							.addComponent(button))
						.addGroup(gl_patient.createSequentialGroup()
							.addGap(18)
							.addComponent(button_1)))
					.addContainerGap(29, Short.MAX_VALUE))
		);
		
		tablepatient = new JTable();
		tablepatient.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tablepatient.setModel(new DefaultTableModel(
			new Object[][] {
				{"1", "\u5F20\u4E09", "123", "\u611F\u5192", "\u5FEB\u514B", "\u4E00\u65E5\u4E09\u6B21"},
				{"2", "\u674E\u56DB", "456", "\u53D1\u70E7", "\u5E03\u6D1B\u82AC", "\u4E00\u65E5\u4E00\u6B21"},
			},
			new String[] {
				"\u75C5\u4EBA\u5E8F\u53F7", "\u75C5\u4EBA\u59D3\u540D", "\u8054\u7CFB\u7535\u8BDD", "\u75C5\u75C7", "\u836F\u65B9", "\u670D\u836F\u5242\u91CF"
			}
		));
		scrollPane.setViewportView(tablepatient);
		patient.setLayout(gl_patient);
		
		JPanel Working = new JPanel();
		seepanel.add(Working, "name_673360697024500");
		
		JLabel label = new JLabel("个人资料");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((CardLayout)seepanel.getLayout()).show(seepanel, "name_673245379164900");
			}
		});
		label.setFont(new Font("微软雅黑", Font.BOLD, 20));
		
		JLabel label_11 = new JLabel("病人查看");
		label_11.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((CardLayout)seepanel.getLayout()).show(seepanel, "name_673258034143900");
			}
		});
		label_11.setFont(new Font("微软雅黑", Font.BOLD, 20));
		
		JLabel label_12 = new JLabel("值班情况");
		label_12.setFont(new Font("微软雅黑", Font.BOLD, 20));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		JPanel panel = new JPanel();
		GroupLayout gl_Working = new GroupLayout(Working);
		gl_Working.setHorizontalGroup(
			gl_Working.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Working.createSequentialGroup()
					.addGroup(gl_Working.createParallelGroup(Alignment.LEADING)
						.addComponent(label)
						.addComponent(label_11)
						.addComponent(label_12))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 381, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 213, GroupLayout.PREFERRED_SIZE)
					.addGap(10))
		);
		gl_Working.setVerticalGroup(
			gl_Working.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_Working.createSequentialGroup()
					.addGap(123)
					.addComponent(label)
					.addGap(18)
					.addComponent(label_11)
					.addGap(18)
					.addComponent(label_12)
					.addContainerGap(153, Short.MAX_VALUE))
				.addGroup(gl_Working.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_Working.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.DEFAULT_SIZE, 383, Short.MAX_VALUE)
						.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 396, Short.MAX_VALUE)))
		);
		
		JLabel lblNewLabel_1 = new JLabel("序号：");
		
		JLabel lblNewLabel_7 = new JLabel("姓名：");
		
		JLabel lblNewLabel_8 = new JLabel("年龄：");
		
		JLabel label_3 = new JLabel("职称：");
		
		JLabel label_4 = new JLabel("");
		
		JLabel lblNewLabel_10 = new JLabel("科室：");
		
		tid = new JTextField();
		tid.setEnabled(false);
		tid.setColumns(10);
		
		tname = new JTextField();
		tname.setColumns(10);
		
		tage = new JTextField();
		tage.setColumns(10);
		
		tfcollege = new JTextField();
		tfcollege.setColumns(10);
		
		tfroom = new JTextField();
		tfroom.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("电话：");
		
		tcall = new JTextField();
		tcall.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addGroup(Alignment.TRAILING, gl_panel.createParallelGroup(Alignment.LEADING)
							.addComponent(lblNewLabel_1)
							.addComponent(lblNewLabel_8)
							.addComponent(lblNewLabel_7)
							.addComponent(label_3)
							.addComponent(lblNewLabel_10))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_4)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(lblNewLabel_11)))
					.addGap(14)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(tcall, GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
						.addComponent(tfroom, GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
						.addComponent(tfcollege, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
						.addComponent(tage, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
						.addComponent(tname, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
						.addComponent(tid, GroupLayout.PREFERRED_SIZE, 134, GroupLayout.PREFERRED_SIZE))
					.addGap(28))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(tid, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_7)
						.addComponent(tname, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_8)
						.addComponent(tage, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(label_3)
						.addComponent(tfcollege, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_10)
						.addComponent(tfroom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(33)
							.addComponent(label_4))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(18)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(tcall, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_11))))
					.addGap(63))
		);
		panel.setLayout(gl_panel);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row = table.getSelectedRow();
				String id = (String) table.getValueAt(row, 0);
				String name = (String) table.getValueAt(row, 1);
				String age = (String) table.getValueAt(row, 2);
				String zhicheng = (String) table.getValueAt(row, 3);
				String keshi = (String) table.getValueAt(row, 4);
				String phone = (String) table.getValueAt(row, 5);
				tname.setText(name);
				tage.setText(age);
				tfcollege.setText(zhicheng);
				tfroom.setText(keshi);
				tid.setText(id);
				tcall.setText(phone);				
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"1", "\u5F20\u4E09", "21", "\u4E3B\u6CBB\u533B\u5E08", "\u5185\u79D1", "13000000000"},
			},
			new String[] {
				"\u5E8F\u53F7", "\u59D3\u540D", "\u5E74\u9F84", "\u804C\u79F0", "\u79D1\u5BA4", "\u7535\u8BDD"
			}
		));
		scrollPane_1.setColumnHeaderView(table);
		Working.setLayout(gl_Working);
		contentPane.setLayout(gl_contentPane);
	}
	
	
	
	public void setUser(User user) {
		this.user = user;
		IPatience contactService = new Patienceimpl();
		List<Patience> contacts = contactService.queryAll(user.getUsername());
		showPatience(contacts);
	}


	private void showPatience(List<Patience> contacts) {
		String[] columnNames = { "病人序号", "病人姓名", "联系方式","病症","药方","用药剂量" };
		Object[][] data = new Object[contacts.size()][6];

		for (int i = 0; i < data.length; i++) {
			data[i][0] = contacts.get(i).getId();
			data[i][1] = contacts.get(i).getPname();
			data[i][2] = contacts.get(i).getPcall();
			data[i][3] = contacts.get(i).getPill();
			data[i][4] = contacts.get(i).getPdrug();
			data[i][5] = contacts.get(i).getPcount();
		}

		// 1、构造一个DefaultTableModel对象
		DefaultTableModel model = new DefaultTableModel(data, columnNames);

		// 2、调用表格的setModel设置数据模型对象
		tablepatient.setModel(model);

		tablepatient.getColumnModel().getColumn(2).setMinWidth(150);
	}
	
}
