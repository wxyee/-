package Doctor.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Doctor.poto.Patience;
import Doctor.service.IPatience;
import Doctor.service.impl.Patienceimpl;


import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;

public class addpatient extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField pname;
	private JTextField pcall;
	private JTextField pill;
	private JTextField pdrug;
	private JTextField pcount;
	private JTextField page;
	private String username;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			addpatient dialog = new addpatient();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * Create the dialog.
	 */
	public addpatient() {
		setTitle("添加病例");
		setBounds(100, 100, 349, 536);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		JLabel label = new JLabel("姓名：");
		label.setFont(new Font("宋体", Font.BOLD, 20));
		JLabel lblNewLabel = new JLabel("性别：");
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 20));
		JLabel lblNewLabel_1 = new JLabel("联系电话：");
		lblNewLabel_1.setFont(new Font("宋体", Font.BOLD, 20));
		JLabel lblNewLabel_2 = new JLabel("病症：");
		lblNewLabel_2.setFont(new Font("宋体", Font.BOLD, 20));
		JLabel lblNewLabel_3 = new JLabel("药方：");
		lblNewLabel_3.setFont(new Font("宋体", Font.BOLD, 20));
		JLabel lblNewLabel_4 = new JLabel("服药剂量：");
		lblNewLabel_4.setFont(new Font("宋体", Font.BOLD, 20));
		JLabel lblNewLabel_5 = new JLabel("年龄：");
		lblNewLabel_5.setFont(new Font("宋体", Font.BOLD, 20));
		pname = new JTextField();
		pname.setColumns(10);
		pcall = new JTextField();
		pcall.setColumns(10);
		
		JRadioButton radmale = new JRadioButton("男");
		radmale.setSelected(true);
		buttonGroup.add(radmale);
		
		JRadioButton radiofemale = new JRadioButton("女");
		buttonGroup.add(radiofemale);
		
		pill = new JTextField();
		pill.setColumns(10);
		
		pdrug = new JTextField();
		pdrug.setColumns(10);
		
		pcount = new JTextField();
		pcount.setColumns(10);
		
		page = new JTextField();
		page.setColumns(10);
		
		JButton btnNewButton = new JButton("添加");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 1、收集数据
				String name =pname.getText();
				String phone = pcall.getText();
				String gender = radmale.isSelected() ? "男" : "女";
				String drug = pdrug.getText();
				String ill = pill.getText();
				String count = pcount.getText();
				String age = page.getText();
				
				// 2、封装对象
				Patience c = new Patience();
				c.setPname(name);
				c.setPcall(phone);
				c.setGender(gender);
				c.setPdrug(drug);
				c.setPill(ill);
				c.setPcount(count);
				c.setPage(age);
				c.setUsername(username);
				
				// 3、调用服务进行存储
				IPatience patienceService = new Patienceimpl();
				int rlt = patienceService.insert(c);
				// 4、结果展示
				if (rlt == 1) {
					JOptionPane.showMessageDialog(addpatient.this, "添加完成！");
				} else {
					JOptionPane.showMessageDialog(addpatient.this, "添加失败！");
				}
			}
		});
		
		JButton btnNewButton_1 = new JButton("取消");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_5)
						.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_contentPanel.createSequentialGroup()
								.addGap(42)
								.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
									.addComponent(lblNewLabel)
									.addComponent(label)))
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblNewLabel_1)
								.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
									.addComponent(lblNewLabel_3)
									.addComponent(lblNewLabel_2)))
							.addComponent(lblNewLabel_4)
							.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
								.addContainerGap()
								.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE))))
					.addPreferredGap(ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(page)
								.addComponent(pcount)
								.addComponent(pdrug)
								.addComponent(pill)
								.addComponent(pcall)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addComponent(radmale)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(radiofemale))
								.addComponent(pname, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE))
							.addGap(35))
						.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(pname, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(radmale)
						.addComponent(radiofemale))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(pcall, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(pill, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(pdrug, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_4)
						.addComponent(pcount, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_5)
						.addComponent(page, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		contentPanel.setLayout(gl_contentPanel);
	}
}
