package Doctor.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Doctor.poto.User;
import Doctor.service.IUserService;
import Doctor.service.impl.Userimpl;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class registfrm extends JFrame {

	private JPanel contentPane;
	private JTextField tfUsername;
	private JTextField tfNickname;
	private JPasswordField pfPwd;

	/**
	 * Create the frame.
	 */
	public registfrm() {
		setTitle("医生信息管理系统");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 494, 362);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("注册");
		lblNewLabel.setFont(new Font("微软雅黑", Font.BOLD, 32));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel label = new JLabel("用户名：");
		
		tfUsername = new JTextField();
		tfUsername.setHorizontalAlignment(SwingConstants.CENTER);
		tfUsername.setColumns(10);
		
		JLabel label_1 = new JLabel("昵称：");
		
		tfNickname = new JTextField();
		tfNickname.setHorizontalAlignment(SwingConstants.CENTER);
		tfNickname.setColumns(10);
		
		JLabel label_2 = new JLabel("密码：");
		
		pfPwd = new JPasswordField();
		pfPwd.setHorizontalAlignment(SwingConstants.CENTER);
		
		JButton btnNewButton = new JButton("注册");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 收集用户信息，进行用户注册
				String username = tfUsername.getText();
				String nickname = tfNickname.getText();
				String password = new String(pfPwd.getPassword());
				
				User user = new User();
				user.setUsername(username);
				user.setNickname(nickname);
				user.setPassword(password);
				
				IUserService userService = new Userimpl();
				int rlt = userService.regist(user);
				switch(rlt) {
				case 0:
					JOptionPane.showMessageDialog(registfrm.this, "注册完成！", "注册", JOptionPane.INFORMATION_MESSAGE);
					break;
				case 1:
					JOptionPane.showMessageDialog(registfrm.this, "注册失败！该用户名已经注册！", "注册", JOptionPane.WARNING_MESSAGE);
					break;
				case 2:
					JOptionPane.showMessageDialog(registfrm.this, "注册失败！数据不完整！", "注册", JOptionPane.WARNING_MESSAGE);
					break;
				case 3:
					JOptionPane.showMessageDialog(registfrm.this, "注册失败！其他原因！", "注册", JOptionPane.ERROR_MESSAGE);
					break;
				}
			}
		});
		
		JButton button = new JButton("登录");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 关闭自己
				registfrm.this.dispose();
				
				// 返回登录窗口
				loginfrm frame = new loginfrm();
				frame.setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 466, Short.MAX_VALUE)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(43)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(label)
						.addComponent(label_1)
						.addComponent(label_2))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnNewButton)
							.addPreferredGap(ComponentPlacement.RELATED, 113, Short.MAX_VALUE)
							.addComponent(button))
						.addComponent(pfPwd, GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
						.addComponent(tfNickname, GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
						.addComponent(tfUsername, GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE))
					.addGap(56))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(tfUsername, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(tfNickname, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(pfPwd, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(button))
					.addContainerGap(110, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
