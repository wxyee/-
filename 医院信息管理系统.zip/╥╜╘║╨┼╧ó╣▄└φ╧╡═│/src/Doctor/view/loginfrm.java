package Doctor.view;


import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import Doctor.poto.User;
import Doctor.service.IUserService;
import Doctor.service.impl.Userimpl;
import Doctor.view.registfrm;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;

public class loginfrm extends JDialog {

	private JPanel contentPanel = new JPanel();
	private JTextField tfusername;
	private JTextField tfpwd;
	private JTextField tfVerifycode;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
		} catch (Exception e) {
			// TODO exception
		}
		try {
			loginfrm dialog = new loginfrm();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public loginfrm() {
		setTitle("医生信息管理系统");
		setBounds(100, 100, 498, 379);
		setLocationRelativeTo(null);
		contentPanel = new MImagePanel(this.getClass().getResource("/imgs/bg.jpg"));
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		JLabel lblVerifycode = new MVerifyLabel();
		JButton btnNewButton = new JButton("登录");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = tfusername.getText();
				String password = new String(tfpwd.getText());
				String verifycode = tfVerifycode.getText();
				
				if (username == null || username.isEmpty() || 
					password == null || password.isEmpty()  
					) {
					JOptionPane.showMessageDialog(loginfrm.this, "您输入的信息不完整！请检查后重新输入！", "登录失败", JOptionPane.WARNING_MESSAGE);
					return; 
				}			
				String realCode = ((MVerifyLabel) lblVerifycode).getCode();
				if (!verifycode.equalsIgnoreCase(realCode)) {
					JOptionPane.showMessageDialog(loginfrm.this, "验证码输入不正确！请检查后重新输入！", "登录失败",
							JOptionPane.WARNING_MESSAGE);
					return; // 出错了，不应该往后继续了！
				}
				IUserService userService = new Userimpl();
				User user = userService.login(username, password);
				if (user == null) {
					JOptionPane.showMessageDialog(loginfrm.this,"用户名或密码输入错误！请检查后重新输入！", "登录失败", JOptionPane.WARNING_MESSAGE);
				} else {
					dispose();
					Message frame = new Message();
					frame.setUser(user);
					frame.setVisible(true);
				}
			
			}
		});
		
		JButton btnNewButton_1 = new JButton("注册");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				
				registfrm frame = new registfrm();
				frame.setVisible(true);
			}
		});
		
		tfusername = new JTextField();
		tfusername.setText("请输入用户名");
		tfusername.setColumns(10);
		
		tfpwd = new JTextField();
		tfpwd.setText("请输入密码");
		tfpwd.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("用户名:");
		
		JLabel lblNewLabel_1 = new JLabel("密  码：");
		
		JLabel lblNewLabel_2 = new JLabel("医生信息管理系统");
		lblNewLabel_2.setFont(new Font("微软雅黑", Font.BOLD, 24));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfVerifycode = new JTextField();
		tfVerifycode.setText("请输入验证码");
		tfVerifycode.setColumns(10);
		
		
		
		
		
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGap(97)
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel)
										.addComponent(lblNewLabel_1))
									.addGap(58)
									.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
										.addComponent(tfusername, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)
										.addComponent(tfpwd, GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE)))
								.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
									.addComponent(tfVerifycode, GroupLayout.PREFERRED_SIZE, 105, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
									.addComponent(lblVerifycode, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE))
								.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
									.addComponent(btnNewButton)
									.addPreferredGap(ComponentPlacement.RELATED, 157, Short.MAX_VALUE)
									.addComponent(btnNewButton_1)))
							.addGap(84)))
					.addContainerGap())
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(tfusername, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(15)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(tfpwd, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblVerifycode, GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
						.addComponent(tfVerifycode, GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
					.addGap(18)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton))
					.addGap(85))
		);
		contentPanel.setLayout(gl_contentPanel);
	}
}
