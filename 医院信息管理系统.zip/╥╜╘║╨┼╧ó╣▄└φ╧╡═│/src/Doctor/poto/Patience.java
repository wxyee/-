package Doctor.poto;

import java.io.Serializable;
import java.util.Date;

public class Patience implements Serializable {
	private int id; // id，唯一【生成规则：1、保存在文件中，每次加1 2、取当前所有联系人的最大id加1】
	private String pname; // 姓名
	private String gender; // 性别
	private String pcall; // 电话
	private String pill; // 病症
	private String pdrug;//药方
	private String pcount;//服药剂量
	private String page;//年龄
	private String username; // 当前病人对应的用户
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPcall() {
		return pcall;
	}
	public void setPcall(String pcall) {
		this.pcall = pcall;
	}
	public String getPill() {
		return pill;
	}
	public void setPill(String pill) {
		this.pill = pill;
	}
	public String getPdrug() {
		return pdrug;
	}
	public void setPdrug(String pdrug) {
		this.pdrug = pdrug;
	}
	public String getPcount() {
		return pcount;
	}
	public void setPcount(String pcount) {
		this.pcount = pcount;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String age) {
		this.page = age;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "Patience [id=" + id + ", pname=" + pname + ", gender=" + gender + ", pcall=" + pcall + ", pill=" + pill
				+ ", pdrug=" + pdrug + ", pcount=" + pcount + ", page=" + page + ", username=" + username + "]";
	}
	
	
}
