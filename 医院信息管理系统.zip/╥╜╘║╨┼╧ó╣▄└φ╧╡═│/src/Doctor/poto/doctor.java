package Doctor.poto;

public class doctor {
	private String name;
	private String id ;
	private String gender;
	private String zhicheng;
	private String keshi;
	private String age;
	private String username;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getZhicheng() {
		return zhicheng;
	}
	public void setZhicheng(String zhicheng) {
		this.zhicheng = zhicheng;
	}
	public String getKeshi() {
		return keshi;
	}
	public void setKeshi(String keshi) {
		this.keshi = keshi;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "doctor [name=" + name + ", id=" + id + ", gender=" + gender + ", zhicheng=" + zhicheng + ", keshi="
				+ keshi + ", age=" + age + ", username=" + username + "]";
	}
	
	

}
