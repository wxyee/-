package Doctor.service;

import Doctor.poto.User;

/**
 * 接口
 * 定义一组行为规范，需要有类来将行为规范具体实现
 */
public interface IUserService {

	/**
	 * 进行用户登录操作
	 * @param username 用户名
	 * @param password 密码
	 * @return 返回相应的用户对象，如果登录失败，返回null
	 */
	User login(String username, String password);
	
	/**
	 * 进行用户注册操作
	 * @param user 要注册的用户
	 * @return 注册的结果，返回0表示注册成功，1表示存在相同的用户名，2表示数据不完整，3表示其他原因
	 */
	int regist(User user);
	
}