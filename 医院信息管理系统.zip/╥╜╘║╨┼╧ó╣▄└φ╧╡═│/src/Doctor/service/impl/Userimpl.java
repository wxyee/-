package Doctor.service.impl;

import Doctor.dao.IUserDao;
import Doctor.dao.impl.UserDaoimpl;
import Doctor.poto.User;
import Doctor.service.IUserService;

public class Userimpl implements IUserService {

	private IUserDao dao = new UserDaoimpl();
	
	@Override
	public User login(String username, String password) {
		// 从数据源中查询有没有对应的用户信息
		return dao.queryByUsernamePassword(username, password);
	}

	@Override
	public int regist(User user) {
		if (user.getUsername() == null || user.getUsername().isEmpty() ||
				user.getPassword() == null || user.getPassword().isEmpty()) {
			return 2;
		}
		
		if (dao.queryByUsername(user.getUsername()) != null) {
			return 1;
		}
		
		// 将用户对象存储到数据源中
		return dao.insert(user);
	}

}