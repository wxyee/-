package Doctor.service.impl;

import java.util.List;

import Doctor.dao.IPatienceDao;
import Doctor.dao.impl.PatienceDaoimpl;
import Doctor.poto.Patience;
import Doctor.service.IPatience;

public class Patienceimpl implements IPatience{
	private IPatienceDao dao = new PatienceDaoimpl();
	@Override
	public int insert(Patience c) {
		if (dao.querypcall(c.getUsername(),c.getPcall()) != null) {
			return 0;
		}
		return dao.insert(c);
	}

	@Override
	public int delete(int id) {
		
		return dao.delete(id);
	}

	@Override
	public int update(Patience c) {
		return dao.update(c);
	}

	public List<Patience> queryAll(String username) {
		return dao.queryAll(username);

	}

	@Override
	public List<Patience> querypname(String username,String pname) {
		return dao.querypname(username,pname);
	}


	public Patience querypcall(String username,String pcall) {
		return dao.querypcall(username,pcall);

	}


	public List<Patience> querypill(String username,String pill) {
		return dao.querypill(username,pill);

	}
	
}
